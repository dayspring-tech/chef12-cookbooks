template "/usr/local/bin/unzip" do
  source "unzip.erb"
  mode 0755
end
